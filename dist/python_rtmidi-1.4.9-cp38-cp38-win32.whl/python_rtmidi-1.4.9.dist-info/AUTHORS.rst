=======
Credits
=======


Development Lead
----------------

* Christopher Arndt <chris@chrisarndt.de>


Contributors
------------

* Michiel Overtoom
* Orhan Kavrakoğlu
* tekHedd
* Maurizio Berti
* Benoit Pierre


Testing
-------

* Martin Tarenskeen
* Pierre Castellotti
